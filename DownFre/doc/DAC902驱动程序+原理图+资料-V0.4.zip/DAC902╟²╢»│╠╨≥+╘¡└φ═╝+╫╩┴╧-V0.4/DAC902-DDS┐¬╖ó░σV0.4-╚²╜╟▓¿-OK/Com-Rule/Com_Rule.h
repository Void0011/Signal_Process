#ifndef _Com_Rule_h_
#define _Com_Rule_h_

#include "sys.h"

extern u8 *Com_dat;
extern u8 Command;
extern u8	Get_Msg_mark;

u8 Data_Deal(u8 dat);
#endif

