#ifndef __ADC_H
#define	__ADC_H


#include "sys.h"


void ADC1_Init(void);
float Get_VIN(void);
float Get_IIN(void);


#endif /* __ADC_H */

